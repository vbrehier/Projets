import Profil_form from './Profil_form';

export default Profil_form;